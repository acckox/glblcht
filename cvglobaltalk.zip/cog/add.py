from discord.ext import commands
from dislash import slash_command, OptionType
import discord
import os
import json

class AddCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(
        name="add",
        description="Add your server to the beaniverse system."
    )
    async def add(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ You must be an administrator to use this command.", ephemeral=True)
            return

        def load_servers():
            if os.path.isfile("servers.json"):
                with open('servers.json', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return {"servers": []}
        
        def save_servers(servers):
            with open('servers.json', 'w') as f:
                json.dump(servers, f, indent=4)

        def load_banned_servers():
            if os.path.isfile("banlist.json"):
                with open("banlist.json", "r") as file:
                    return json.load(file)["banned_servers"]
            else:
                return []
        
        def get_global_chat(guild_id, channel_id=None):
            servers = load_servers()
            for server in servers["servers"]:
                if server["guildid"] == str(guild_id):
                    if channel_id and server["channelid"] == str(channel_id):
                        return server
                    elif not channel_id:
                        return server
            return None

        servers = load_servers()
        banned_servers = load_banned_servers()

        guild_id = str(ctx.guild.id)
        channel_id = str(ctx.channel.id)

        for banned_server in banned_servers:
            if banned_server["guildid"] == guild_id:
                await ctx.send("❌ This server is banned and cannot be added to the beaniverse.", ephemeral=True)
                return

        existing_global_chat = get_global_chat(guild_id)
        if existing_global_chat:
            existing_global_chat_channel = self.bot.get_channel(int(existing_global_chat["channelid"]))
            embed = discord.Embed(
                description=f"### ⚠ Your server already has an existing beaniverse channel\n {existing_global_chat_channel.mention}\n"
                            "Please note that each server can only have 1 beaniverse channel.\n"
                            "If any problems occurs, kindly contact the owner of this bot <@624471886054686731>. Thanks!",
                color=0x000000
            )
            await ctx.send(embed=embed)
            return

        invite = await ctx.channel.create_invite()
        server = {
            "guildid": guild_id,
            "channelid": channel_id,
            "invite": invite.url
        }
        servers["servers"].append(server)
        save_servers(servers)

        embed = discord.Embed(
            title="welcome to beans's server-to-server chat!",
            url ="https://www.youtube.com/watch?v=xvFZjo5PgG0&ab_channel=Duran",
            description="## __✅ Your server is now ready!__\n"
                        "All messages sent in this channel will be redirected to all servers that have this bot.\n"
                        "**Allowed formats**: text, .png, and .jpeg\n"
                        "**Prohibited formats**: any attachments not mentioned above\n"
                        "### __⚠ Note:__\n"
                        "Avoid spamming to keep the bot responsive. If any problems occur, kindly contact the owner of [this bot](https://discord.gg/4879ESxZPk) <@624471886054686731>. Thanks! \n\n"
                        "### __Friendly Reminder:__\n To avoid getting banned, ensure that your messages are appropriate for your server and everyone. Depending on the situation, you might be subject to penalties from your server administrators, and Discord itself.",
            color=0x2ecc71
        )
        embed.set_footer(text='🇵🇭  ·  Made in beans server')
        await ctx.send(embed=embed)

        notification = f"ℹ️ **New Server Joined! @here **\n\n"
        notification += f"Server Name: {ctx.guild.name}\n"
        notification += f"Server ID: {guild_id}\n"
        notification += f"Total Servers in beaniverse: {len(servers['servers'])}\n"
        notification += f"beaniverse Channel: {ctx.channel.mention}\n"

        for server in servers["servers"]:
            guild = self.bot.get_guild(int(server["guildid"]))
            if guild:
                channel = guild.get_channel(int(server["channelid"]))
                if channel:
                    await channel.send(notification)


def setup(bot):
    bot.add_cog(AddCog(bot))
