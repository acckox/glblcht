from discord.ext import commands
from dislash import slash_command, OptionType, Option, Button, ActionRow
import discord

class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(
        name="help",
        description="Get help and information about the beaniverse bot"
    )
    async def help_command(self, inter, command=None):
        if command:
            await inter.send("Command not found.")
        else:
            embed = discord.Embed(
                title="beanieverse commands",
                description=" ",
                color=0x000000
            )

            embed.add_field(
                name="`/help`",
                value="Shows this message.",
                inline=False
            )

            embed.add_field(
                name="`/add`",
                value="Add your server to the beaniverse system. **Admin** perms required.",
                inline=False
            )

            embed.add_field(
                name="`/remove`",
                value="Remove your server from the beaniverse system. **Admin** perms required.",
                inline=False
            )

            embed.add_field(
                name="`/mute`",
                value="Mute a user in the beaniverse channel. **Admin** perms required.",
                inline=False
            )

            embed.add_field(
                name="`/unmute`",
                value="Unmute a user in the beaniverse channel. **Admin** perms required.",
                inline=False
            )

            button = Button(
                style=5, 
                label="Support Server",
                url="https://discord.gg/4879ESxZPk"  
            )

            action_row = ActionRow(button)

            await inter.send(embed=embed, components=[action_row])

def setup(bot):
    bot.add_cog(HelpCog(bot))
