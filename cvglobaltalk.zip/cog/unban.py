import discord
from discord.ext import commands
import json
import os
from dotenv import load_dotenv

load_dotenv() 

class UnbanCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.owner_id = int(os.getenv("BOT_OWNER_ID"))

    def load_servers(self):
        try:
            with open('servers.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {"servers": []}

    def save_servers(self, servers):
        with open('servers.json', 'w', encoding='utf-8') as f:
            json.dump(servers, f, indent=4)

    def load_banned_servers(self):
        try:
            with open('banlist.json', 'r', encoding='utf-8') as f:
                return json.load(f)["banned_servers"]
        except FileNotFoundError:
            return []

    def save_banned_servers(self, banned_servers):
        with open('banlist.json', 'w', encoding='utf-8') as f:
            json.dump({"banned_servers": banned_servers}, f, indent=4)

    async def announce_unbanned_server(self, unbanned_server):
        servers = self.load_servers()

        for server in servers["servers"]:
            guild_id = int(server["guildid"])
            try:
                guild = self.bot.get_guild(guild_id)
                channel_id = int(server["channelid"])
                channel = guild.get_channel(channel_id)

                if channel:
                    unbanned_guild = await self.bot.fetch_guild(unbanned_server['guildid'])
                    unbanned_server_name = unbanned_guild.name
                    
                    embed = discord.Embed(
                        title=f"Server '{unbanned_server_name}' Unbanned",
                        description=f"The server with ID {unbanned_server['guildid']} is now available in the beaniverse.",
                        color=discord.Color.green()  
                    )
                    await channel.send(embed=embed)
            except Exception as e:
                print(f"Error announcing to server {guild_id}: {e}")

    @commands.command()
    async def unban_server(self, ctx, guild_id: int):
        if ctx.author.id != self.owner_id:
            await ctx.send("Only the bot owner can use this command.")
            return
    
        banned_servers = self.load_banned_servers() 
    
        for index, server in enumerate(banned_servers):
            if server["guildid"] == str(guild_id):
                unbanned_server = {
                    "guildid": server["guildid"],
                    "channelid": server["channelid"],
                    "invite": server["invite"]
                }
                banned_servers.pop(index)
                self.save_banned_servers(banned_servers)
                servers = self.load_servers()  
                servers["servers"].append(unbanned_server)
                self.save_servers(servers)
    
                await self.announce_unbanned_server(unbanned_server)  # Announce the unban
                await ctx.send(f"Unbanned server with ID {guild_id} and added to beaniverse.")
                return
    
        await ctx.send(f"Server with ID {guild_id} is not in the banned server list.")

def setup(bot):
    bot.add_cog(UnbanCog(bot))
