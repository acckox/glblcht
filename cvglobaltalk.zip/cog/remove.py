import discord
from discord.ext import commands
from dislash import Option, OptionType, slash_command
import os
import json

class Remove(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(
        name="remove",
        description="Remove your server from the beaniverse system."
    )
    async def remove(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            await ctx.send(
                "❌ You must have administrator permission to use this command.",
                ephemeral=True
            )
            return
        servers = self.load_servers()
        banned_servers = self.load_banned_servers()
        guild_id = str(ctx.guild.id)
        channel_id = str(ctx.channel.id)

        for banned_server in banned_servers:
            if banned_server["guildid"] == guild_id:
                await ctx.send("❌ This server is banned and cannot be removed from the beaniverse.", ephemeral=True)
                return

        global_chat = self.get_global_chat(guild_id, channel_id)

        if global_chat:
            servers["servers"].remove(global_chat)
            self.save_servers(servers)

            embed = discord.Embed(
                description="# Your server has been removed from the beaniverse system. \n Balik po kayo!",
                color=0xFF0000
            )
            await ctx.send(embed=embed)

            notification = f"❗ **Server Left!**\n\n"
            notification += f"Server Name: {ctx.guild.name}\n"
            notification += f"Server ID: {guild_id}\n"
            notification += f"Total Servers in beaniverse: {len(servers['servers'])}\n"

            for server in servers["servers"]:
                guild = self.bot.get_guild(int(server["guildid"]))
                if guild:
                    channel = guild.get_channel(int(server["channelid"]))
                    if channel:
                        await channel.send(notification)
        else:
            if self.get_global_chat(guild_id):
                global_chat_channel_id = self.get_global_chat(guild_id)["channelid"]
                global_chat_channel = self.bot.get_channel(int(global_chat_channel_id))
                embed = discord.Embed(
                    description=f"⚠ Please use the `/remove` command in the beaniverse channel ({global_chat_channel.mention}) of your server.",
                    color=0xFF0000
                )
            else:
                embed = discord.Embed(
                    description="⚠ Your server is not in the beaniverse system.",
                    color=0x000000
                )
            await ctx.send(embed=embed)

    def load_servers(self):
        if os.path.isfile("servers.json"):
            with open('servers.json', encoding='utf-8') as f:
                return json.load(f)
        else:
            return {"servers": []}

    def save_servers(self, servers):
        with open('servers.json', 'w') as f:
            json.dump(servers, f, indent=4)

    def load_banned_servers(self):
        if os.path.isfile("banlist.json"):
            with open("banlist.json", "r") as file:
                return json.load(file)["banned_servers"]
        else:
            return []

    def get_global_chat(self, guild_id, channel_id=None):
        servers = self.load_servers()
        for server in servers["servers"]:
            if server["guildid"] == str(guild_id):
                if channel_id and server["channelid"] == str(channel_id):
                    return server
                elif not channel_id:
                    return server
        return None

def setup(bot):
    bot.add_cog(Remove(bot))
