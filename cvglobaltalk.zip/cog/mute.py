import discord
from discord.ext import commands
from dislash import Option, OptionType, slash_command
import json
from dotenv import load_dotenv
import os

load_dotenv()

class BanCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.owner_id = int(os.getenv("BOT_OWNER_ID"))

    def load_servers(self):
        try:
            with open('servers.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {"servers": []}

    def save_servers(self, servers):
        with open('servers.json', 'w', encoding='utf-8') as f:
            json.dump(servers, f, indent=4)

    def load_banned_servers(self):
        try:
            with open('banlist.json', 'r', encoding='utf-8') as f:
                return json.load(f)["banned_servers"]
        except FileNotFoundError:
            return []

    def save_banned_servers(self, banned_servers):
        with open('banlist.json', 'w', encoding='utf-8') as f:
            json.dump({"banned_servers": banned_servers}, f, indent=4)

    async def announce_banned_server(self, banned_server):
        servers = self.load_servers()

        for server in servers["servers"]:
            guild_id = int(server["guildid"])
            try:
                guild = self.bot.get_guild(guild_id)
                channel_id = int(server["channelid"])
                channel = guild.get_channel(channel_id)

                if channel:
                    banned_guild = await self.bot.fetch_guild(banned_server['guildid'])
                    banned_server_name = banned_guild.name
                    await channel.send(f"The server '{banned_server_name}' with ID {banned_server['guildid']} has been banned from the beaniverse.")
            except Exception as e:
                print(f"Error announcing to server {guild_id}: {e}")

    @slash_command(
        name="ban_server",
        description="Ban a server from the beaniverse.",

        options=[
            Option(
                name="guild_id",
                description="ID of the server to ban",
                type=OptionType.INTEGER,
                required=True
            )
        ]
    )
    async def ban_server(self, ctx):
        if ctx.author.id != self.owner_id:
            await ctx.send("Only the bot owner can use this command.", ephemeral=True)
            return
        
        guild_id = ctx.get("guild_id")  # Retrieve the guild_id parameter from the context
        servers = self.load_servers()

        for index, server in enumerate(servers["servers"]):
            if server["guildid"] == str(guild_id):
                banned_server = {
                    "guildid": server["guildid"],
                    "channelid": server["channelid"],
                    "invite": server["invite"]
                }
                banned_servers = self.load_banned_servers()
                banned_servers.append(banned_server)
                self.save_banned_servers(banned_servers)
                servers["servers"].pop(index)
                self.save_servers(servers)

                await self.announce_banned_server(banned_server)
                await ctx.send(f"Banned server with ID {guild_id} from beaniverse.", ephemeral=True)
                return

        await ctx.send(f"Server with ID {guild_id} is not in the beaniverse list.", ephemeral=True)

def setup(bot):
    bot.add_cog(BanCog(bot))
