import discord
from discord.ext import commands
from dislash import Option, OptionType, slash_command
import json

class Unmute(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(
        name="unmute",
        description="Unmute a user in the global chat.",
        options=[
            Option(
                name="user",
                description="User to unmute",
                type=OptionType.USER,
                required=True
            )
        ]
    )
    async def unmute(self, ctx, user: discord.Member):
        if not ctx.author.guild_permissions.administrator:
            await ctx.send("You need to have administrator permissions to use this command.", ephemeral=True)
            return
        
        servers = self.load_servers()
        guild_id = str(ctx.guild.id)
        global_chat = self.get_global_chat(guild_id)
    
        if global_chat:
            channel_id = int(global_chat["channelid"])
            channel = self.bot.get_channel(channel_id)
            if channel:
                overwrite = channel.overwrites_for(user)
                overwrite.send_messages = True
                await channel.set_permissions(user, overwrite=overwrite)

                embed = discord.Embed(
                    title="User Unmuted",
                    description=f"{user.mention} has been unmuted in the global chat.",
                    color=discord.Color.green()
                )
                await ctx.send(embed=embed)
            else:
                await ctx.send("Unable to find the specified channel.", ephemeral=True)
        else:
            await ctx.send("Your server is not in the global chat system.", ephemeral=True)

    def load_servers(self):
        with open('servers.json', encoding='utf-8') as f:
            return json.load(f)

    def get_global_chat(self, guild_id):
        servers = self.load_servers()
        for server in servers["servers"]:
            if server["guildid"] == guild_id:
                return server
        return None

def setup(bot):
    bot.add_cog(Unmute(bot))
