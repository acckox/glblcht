import os
import re
import time
import json
import discord
from dislash import InteractionClient, OptionType, Option
import asyncio
from discord.ext import commands
from dotenv import load_dotenv
from webserver import keep_alive
import asyncio

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='//', intents=intents)
slash = InteractionClient(bot)


@bot.event
async def on_ready():
    print('Logged in!')
    asyncio.create_task(status_task())

async def status_task():
    statuses = [
        discord.Activity(type=discord.ActivityType.watching, name=f"{len(bot.guilds)} servers!"),
        discord.Activity(type=discord.ActivityType.competing, name="discord.gg/beans"),
        discord.Streaming(name="beans' agony", url='https://twitch.tv/officialcryhitx')
    ]
    status_index = 0

    while True:
        try:
            await bot.change_presence(activity=statuses[status_index], status=discord.Status.dnd)
        except Exception as e:
            print(f"Error changing presence: {e}")

        status_index = (status_index + 1) % len(statuses)
        await asyncio.sleep(5)

def load_servers():
    if os.path.isfile("servers.json"):
        with open('servers.json', encoding='utf-8') as f:
            return json.load(f)
    else:
        return {"servers": []}

def save_servers(servers):
    with open('servers.json', 'w') as f:
        json.dump(servers, f, indent=4)

def load_banned_servers():
    if os.path.isfile("banlist.json"):
        with open("banlist.json", "r") as file:
            return json.load(file)["banned_servers"]
    else:
        return []

def save_banned_servers(banned_servers):
    with open("banlist.json", "w") as file:
        json.dump({"banned_servers": banned_servers}, file, indent=4)

def get_global_chat(guild_id, channel_id=None):
    servers = load_servers()
    for server in servers["servers"]:
        if server["guildid"] == str(guild_id):
            if channel_id and server["channelid"] == str(channel_id):
                return server
            elif not channel_id:
                return server
    return None

def load_blacklisted_words():
    with open('blacklist.txt', 'r') as file:
        return [word.strip().lower() for word in file.readlines()]

blacklisted_words = load_blacklisted_words()

# new commands here
# currently no commands, nasa cog directory na lahat
# cogs
initial_extensions = [
    'cog.unmute', 'cog.add', 'cog.remove', 'cog.mute', 'cog.help', 'cog.ban', 'cog.unban'
]

if __name__ == '__main__':
    for extension in initial_extensions:
        try:
            bot.load_extension(extension)
        except Exception as e:
            print(f'Failed to load extension {extension}: {str(e)}')

#beaniverse event
user_message_counts = {}

@bot.event
async def on_message(message):
    if message.author.bot:
        return
      
    #banned servers
    banned_servers = load_banned_servers()
    for banned_server in banned_servers:
        if banned_server["guildid"] == str(message.guild.id):
            await message.channel.send(f"⚠️ This server is banned. You cannot send messages here.")
            return

    # Check for spam
    # Check if the server is a global chat server
    global_chat = get_global_chat(message.guild.id, message.channel.id)
    if global_chat:
        # Check for banned servers
        banned_servers = load_banned_servers()
        for banned_server in banned_servers:
            if banned_server["guildid"] == str(message.guild.id):
                await message.channel.send(f"⚠️ This server is banned. You cannot send messages here.")
                return

        # Spam prevention mechanism
        current_time = time.time()
        if message.author.id in user_message_counts:
            message_times = user_message_counts[message.author.id]
            message_times = [t for t in message_times if current_time - t < 3]

            if len(message_times) >= 1:
                remaining_cooldown = round(max(0, 2 - (current_time - message_times[-1])), 2)
                remaining_cooldown_unix = int(current_time + remaining_cooldown)

                warning_message = (
                    f"⚠️ Warning: Please avoid spamming, {message.author.mention}! "
                    f"Cooldown remaining until: <t:{remaining_cooldown_unix}:R>."
                )

                warning = await message.channel.send(warning_message)
                user_message_counts[message.author.id] = [t for t in message_times if current_time - t < 2]

                await asyncio.sleep(2)
                await warning.delete()
                return

        # Update user message counts
        if message.author.id not in user_message_counts:
            user_message_counts[message.author.id] = []
        user_message_counts[message.author.id].append(current_time)
  
    # blacklisted words
    if not message.content.startswith(';'):
        global_chat = get_global_chat(message.guild.id, message.channel.id)
        if global_chat:
            for word in blacklisted_words:
                if word in message.content.lower():
                    await message.delete()
                    await message.channel.send(f"⚠️ Warning: Your message contains a blacklisted word, {message.author.mention}.")

                    audit_log_channel = discord.utils.get(message.guild.text_channels, name="s2s-logs")
                    if audit_log_channel:
                        embed = discord.Embed(color=discord.Color.red())
                        embed.description = f"Message containing a blacklisted word from beans: {message.content}"
                        embed.set_footer(text=f"From {message.guild.name} (Guild ID: {message.guild.id})", icon_url=message.guild.icon_url)
                        await audit_log_channel.send(embed=embed)

                    for server in load_servers()["servers"]:
                        if server["guildid"] != str(message.guild.id):
                            guild = bot.get_guild(int(server["guildid"]))
                            if guild:
                                audit_log_channel_server = discord.utils.get(guild.text_channels, name="s2s-logs")
                                if audit_log_channel_server:
                                    embed_server = discord.Embed(color=discord.Color.red())
                                    embed_server.description = f"Message containing a blacklisted word by {message.author.name}:\n\n **{message.content}**"
                                    embed_server.set_footer(text=f"From {message.guild.name} (Guild ID: {message.guild.id})", icon_url=message.guild.icon_url)
                                    await audit_log_channel_server.send(embed=embed_server)
                    return

            await send_all(message)
    await bot.process_commands(message)


#message-handler
async def send_all(message):

#    if not message.channel.is_nsfw():
#       warning_message = await message.channel.send("🤔 Mhmm? HAXX!? Silly admins. Turn on again the NSFW settings to chat to our bot.")
      
#        async def delete_warning_message():
#            await asyncio.sleep(3)
#            await warning_message.delete()
#          
#        asyncio.create_task(delete_warning_message())
#
#        await message.delete()
#        return
  
    servers = load_servers()
    content = message.content
    author = message.author
    attachments = message.attachments
    has_attachments = any(
        attachment.url.lower().endswith(('.png', '.jpeg', '.jpg', '.gif', '.mp4', '.mov', '.avi', '.wmv'))
        for attachment in attachments
    )
  
    if re.search(r'(discord\.gg|discord\.com\/invite\/)', content):
        warning = "⚠️ **Warning:** Please avoid sharing Discord server invite links in the beaniverse"
        await message.channel.send(warning)
        await message.delete()
        return
    
    tenor_links = re.findall(r'https?:\/\/tenor\.com\/[^ \n]+', content)
    if tenor_links:
        for link in tenor_links:
            for server in servers["servers"]:
                if server["guildid"] != str(message.guild.id):
                    guild = bot.get_guild(int(server["guildid"]))
                    if guild:
                        channel = guild.get_channel(int(server["channelid"]))
                        if channel:
                            embed = discord.Embed(color=0x000000)
                            embed.set_author(name=author.name, icon_url=author.avatar_url)
                            embed.set_footer(text=f"From {message.guild.name}", icon_url=message.guild.icon_url)
                            link_text = "\n".join(f"[Sent a GIF below!]({link})" for link in tenor_links)
                            embed.add_field(name=" ", value=link_text, inline=False)
                            await channel.send(embed=embed)

        simple_message = " ".join(tenor_links)
        for server in servers["servers"]:
            if server["guildid"] != str(message.guild.id):
                guild = bot.get_guild(int(server["guildid"]))
                if guild:
                    channel = guild.get_channel(int(server["channelid"]))
                    if channel:
                        await channel.send(simple_message)

        return

  #as
  
    if content or has_attachments:
        for server in servers["servers"]:
            if server["guildid"] != str(message.guild.id):
                guild = bot.get_guild(int(server["guildid"]))
                if guild:
                    channel = guild.get_channel(int(server["channelid"]))
                    if channel:
 
                        webhooks = await channel.webhooks()
                        webhook = next((wh for wh in webhooks if wh.name == "beaniverse Webhook"), None)

                        if webhook is None:

                            webhook = await channel.create_webhook(name="beaniverse Webhook")

#                        links = '[Bot](https://discord.gg/) & '
#                        global_chat = get_global_chat(message.guild.id, message.channel.id)
#                        if global_chat and len(global_chat["invite"]) > 0:
#                            invite = global_chat["invite"]
#                            if 'discord.gg' not in invite:
#                                invite = 'https://discord.gg/{}'.format(invite)
#                            links += f'[Sender\'s]({invite}) server'

                        embed = discord.Embed(color=author.color)
                        embed.description = f"> {content}"

                        if has_attachments:
                            attachment_types = {
                                '.gif': 'GIF',
                                ('.png', '.jpeg', '.jpg'): 'image',
                                ('.mp4', '.mov', '.avi', '.wmv'): 'video file'
                            }
                            attachment_urls = []
                            attachment_description = ""

                            for attachment in attachments:
                                attachment_url = attachment.url.lower()
                                for ext, attachment_type in attachment_types.items():
                                    if attachment_url.endswith(ext):
                                        if attachment_type == 'GIF' or attachment_type == 'image':
                                            embed.set_image(url=attachment.url)
                                        elif attachment_type == 'video file':
                                            attachment_description += f"[Download {attachment_type}]({attachment.url})\n"
                                        attachment_urls.append(attachment.url)
                                        break

                            if attachment_urls:
                                name = f"{author.name} sent a message and an attachment" if content else f"{author.name} sent an attachment"
                                embed.set_author(
                                    name=name,
                                    icon_url=author.avatar_url or author.default_avatar_url
                                )

                            if attachment_description:
                                embed.add_field(
                                    name=' ',
                                    value=attachment_description,
                                    inline=False
                                )
                        else:
                            name = f"{author.name} sent a message"
                            embed.set_author(
                                name=name,
                                icon_url=author.avatar_url or author.default_avatar_url
                            )

#                        embed.add_field(name='⠀', value='⠀', inline=False)
#                        embed.add_field(name='```    JOIN OUR SERVERS    ```', value=links, inline=False)
                        embed.set_footer(text=f"From {message.guild.name} (ID: {message.guild.id})", icon_url=message.guild.icon_url)


                        await webhook.send(
                            username=author.name,
                            avatar_url=author.avatar_url or author.default_avatar_url,
                            embed=embed
                        )


keep_alive()
load_dotenv()
bot.run(os.getenv('TOKEN'))
